#include "button.h"
#include "lpc17xx.h"

#include "../led/led.h"
#include <stdio.h>


uint8_t current_value = 1;
uint8_t old_value = 0;

void all_LED_off(){
	LED_Off(0);
	LED_Off(1);
	LED_Off(2);
	LED_Off(3);
	LED_Off(4);
	LED_Off(5);
	LED_Off(6);
	LED_Off(7);
}

void EINT0_IRQHandler (void)	  
{
	//terzo
	//reset
	
	current_value = 1;
	old_value = 0;
	all_LED_off();
	LED_On(0);
	
  LPC_SC->EXTINT &= (1 << 0);     /* clear pending interrupt */
}


void EINT1_IRQHandler (void)	  
{
	
	//rprimo
	//avanti
	
	if(current_value < 233){
		current_value = current_value+old_value;
		old_value = current_value-old_value;
	}
	
	LED_Out(current_value);
	
	LPC_SC->EXTINT &= (1 << 1);     /* clear pending interrupt */
}

void EINT2_IRQHandler (void)	  
{
	//secondo
	//indietro
	
	if(old_value!=0){
		old_value = current_value - old_value;
		current_value = current_value - old_value;
	}
	
	LED_Out(current_value);
	
	
	LPC_SC->EXTINT &= (1 << 2);     /* clear pending interrupt         */  
}


